package com.rladntjd85.backoffice.category.service;

import com.rladntjd85.backoffice.category.domain.Category;
import com.rladntjd85.backoffice.category.dto.CategoryForm;
import com.rladntjd85.backoffice.category.repository.CategoryRepository;
import com.rladntjd85.backoffice.product.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AdminCategoryService {

    private static final String LOCK_MSG = "상품을 이동하거나 삭제 후에 수정 및 변경가능합니다.";

    private final CategoryRepository categoryRepository;
    private final ProductRepository productRepository;

    @Transactional(readOnly = true)
    public Page<Category> search(String q, String status, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return categoryRepository.search(q, status, pageable);
    }

    @Transactional(readOnly = true)
    public long totalCount(String q) {
        return categoryRepository.countAllByQ(q);
    }

    @Transactional(readOnly = true)
    public long activeCount(String q) {
        return categoryRepository.countActiveByQ(q);
    }

    @Transactional(readOnly = true)
    public long inactiveCount(String q) {
        return categoryRepository.countInactiveByQ(q);
    }

    @Transactional(readOnly = true)
    public Category get(Long id) {
        return categoryRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("카테고리를 찾을 수 없습니다."));
    }

    @Transactional(readOnly = true)
    public List<Category> getParentList() {
        return categoryRepository.findByParentIsNullAndEnabledTrueOrderByNameAsc();
    }

    @Transactional
    public Long create(CategoryForm form) {
        Category parent = null;
        if (form.parentId() != null) {
            parent = get(form.parentId());
        }

        if (categoryRepository.existsByParentAndNameIgnoreCase(parent, form.name())) {
            throw new IllegalArgumentException("이미 해당 위치에 존재하는 카테고리명입니다.");
        }

        Category c = Category.builder()
                .name(form.name().trim())
                .parent(parent)
                .enabled(true)
                .build();

        return categoryRepository.save(c).getId();
    }

    @Transactional
    public void update(Long id, CategoryForm form) {
        Category c = get(id); // 기존 엔티티 조회

        // 1. 상위 카테고리(부모) 변경 처리 및 제약 조건 검사
        Long newParentId = form.parentId();
        Category currentParent = c.getParent();
        Long currentParentId = (currentParent != null) ? currentParent.getId() : null;

        // 부모 카테고리가 변경되려는 경우에만 체크
        if (isParentChanged(currentParentId, newParentId)) {

            // 제약 1: 자기 자신을 상위 카테고리로 지정 불가
            if (id.equals(newParentId)) {
                throw new IllegalArgumentException("자기 자신을 상위 카테고리로 지정할 수 없습니다.");
            }

            // 제약 2: 하위 카테고리가 존재하는 경우, 다른 카테고리의 하위로 이동 불가 (2단 계층 유지)
            if (!c.getChildren().isEmpty() && newParentId != null) {
                throw new IllegalArgumentException("하위 카테고리가 존재하는 카테고리는 다른 카테고리의 하위로 이동할 수 없습니다.");
            }

            // 부모 변경 적용
            if (newParentId != null) {
                Category parent = get(newParentId);
                c.changeParent(parent); //
            } else {
                c.changeParent(null); // 1차 카테고리로 변경
            }
        }

        // 2. 이름 변경 처리 (중복 체크 포함)
        String newName = form.name().trim();
        if (!c.getName().equalsIgnoreCase(newName)) {
            // 동일 부모 내에 중복 이름이 있는지 확인
            if (categoryRepository.existsByParentAndNameIgnoreCase(c.getParent(), newName)) {
                throw new IllegalArgumentException("이미 해당 위치에 존재하는 카테고리명입니다.");
            }
            c.rename(newName);
        }
    }

    @Transactional(readOnly = true)
    public List<Category> getParentListExceptMe(Long id) {
        // 1차 카테고리 중에서 현재 수정 중인 본인의 ID만 제외하고 조회
        return categoryRepository.findByParentIsNullAndEnabledTrueAndIdNotOrderByNameAsc(id);
    }

    @Transactional
    public void disable(Long id) {
        Category c = get(id);
        if (productRepository.existsByCategoryId(id)) {
            throw new IllegalArgumentException(LOCK_MSG);
        }
        c.disable();
    }

    @Transactional
    public void enable(Long id) {
        Category c = get(id);
        c.enable();
    }

    @Transactional
    public void delete(Long id) {
        // v1: 물리 삭제 (단, 상품 있으면 금지)
        if (productRepository.existsByCategoryId(id)) {
            throw new IllegalArgumentException(LOCK_MSG);
        }
        categoryRepository.deleteById(id);
    }

    // 부모 변경 여부 확인을 위한 헬퍼 메서드
    private boolean isParentChanged(Long currentId, Long newId) {
        if (currentId == null && newId == null) return false;
        if (currentId == null || newId == null) return true;
        return !currentId.equals(newId);
    }
}
