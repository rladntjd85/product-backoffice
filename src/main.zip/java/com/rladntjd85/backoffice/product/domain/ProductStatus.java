package com.rladntjd85.backoffice.product.domain;

public enum ProductStatus {
    ACTIVE, HIDDEN, SOLD_OUT, DELETED
}
