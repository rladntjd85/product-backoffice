package com.rladntjd85.backoffice.auth.domain;

public enum Role {
    ADMIN, MD, VIEWER
}
